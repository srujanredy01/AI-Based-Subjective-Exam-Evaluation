const { GoogleGenerativeAI } = require('@google/generative-ai');
const Evaluation = require('../models/Evaluation');
const Submission = require('../models/Submission');

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// Build the prompt for Gemini
const buildPrompt = (question, modelAnswer, studentAnswer, rubric, maxMarks) => `
You are an expert academic examiner. Evaluate the student's answer fairly and thoroughly.

QUESTION:
${question}

MODEL ANSWER (Reference):
${modelAnswer}

RUBRIC:
- Excellent (${Math.round(maxMarks * 0.9)}-${maxMarks} marks): ${rubric?.excellent || 'Comprehensive, accurate, well-structured answer'}
- Good (${Math.round(maxMarks * 0.7)}-${Math.round(maxMarks * 0.89)} marks): ${rubric?.good || 'Mostly correct with minor gaps'}
- Average (${Math.round(maxMarks * 0.5)}-${Math.round(maxMarks * 0.69)} marks): ${rubric?.average || 'Partially correct, significant gaps'}
- Poor (0-${Math.round(maxMarks * 0.49)} marks): ${rubric?.poor || 'Largely incorrect or insufficient'}

STUDENT ANSWER:
${studentAnswer || '[No answer provided]'}

MAXIMUM MARKS: ${maxMarks}

Evaluate and respond in STRICT JSON format only (no markdown, no extra text):
{
  "marksAwarded": <number between 0 and ${maxMarks}>,
  "strengths": ["<strength 1>", "<strength 2>", "<strength 3>"],
  "areasOfImprovement": ["<area 1>", "<area 2>", "<area 3>"],
  "feedback": "<detailed 2-3 sentence feedback>",
  "reasoning": "<brief explanation of marks awarded>"
}
`;

// Evaluate a single question with Gemini
const evaluateQuestion = async (model, question, studentAnswer, maxMarks, rubric) => {
  const prompt = buildPrompt(
    question.questionText,
    question.modelAnswer,
    studentAnswer,
    rubric || question.rubric,
    maxMarks
  );

  try {
    const result = await model.generateContent(prompt);
    const text = result.response.text();
    // Strip markdown code fences if present
    const clean = text.replace(/```json|```/g, '').trim();
    return JSON.parse(clean);
  } catch (err) {
    console.error('Gemini parse error:', err.message);
    return {
      marksAwarded: 0,
      strengths: ['Unable to evaluate'],
      areasOfImprovement: ['Please resubmit or contact teacher'],
      feedback: 'AI evaluation encountered an error for this question.',
      reasoning: 'Parse error',
    };
  }
};

// Main evaluation function
exports.evaluateWithGemini = async (submissionId, exam, answers, studentId) => {
  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
    const questionEvaluations = [];
    let totalMarksAwarded = 0;
    let allStrengths = [];
    let allAreasOfImprovement = [];

    for (const question of exam.questions) {
      const studentAnswerObj = answers.find(
        a => a.questionId === question._id.toString()
      );
      const studentAnswer = studentAnswerObj?.answerText || '';

      const evalResult = await evaluateQuestion(
        model,
        question,
        studentAnswer,
        question.maxMarks,
        question.rubric
      );

      const marks = Math.min(Math.max(Number(evalResult.marksAwarded) || 0, 0), question.maxMarks);
      totalMarksAwarded += marks;
      allStrengths = [...allStrengths, ...(evalResult.strengths || [])];
      allAreasOfImprovement = [...allAreasOfImprovement, ...(evalResult.areasOfImprovement || [])];

      questionEvaluations.push({
        questionId: question._id,
        questionText: question.questionText,
        studentAnswer,
        modelAnswer: question.modelAnswer,
        marksAwarded: marks,
        maxMarks: question.maxMarks,
        strengths: evalResult.strengths || [],
        areasOfImprovement: evalResult.areasOfImprovement || [],
        feedback: evalResult.feedback || '',
        aiReasoning: evalResult.reasoning || '',
      });

      // Small delay to respect rate limits
      await new Promise(r => setTimeout(r, 500));
    }

    const percentage = exam.totalMarks > 0 ? (totalMarksAwarded / exam.totalMarks) * 100 : 0;

    // Overall feedback via Gemini
    let overallFeedback = '';
    try {
      const overallPrompt = `
Based on a student scoring ${totalMarksAwarded}/${exam.totalMarks} (${percentage.toFixed(1)}%) on "${exam.title}":
Key strengths: ${allStrengths.slice(0, 3).join(', ')}
Key areas to improve: ${allAreasOfImprovement.slice(0, 3).join(', ')}

Write a single encouraging yet honest 2-3 sentence overall feedback paragraph for the student.`;
      const overallResult = await model.generateContent(overallPrompt);
      overallFeedback = overallResult.response.text().trim();
    } catch (e) {
      overallFeedback = `You scored ${totalMarksAwarded} out of ${exam.totalMarks}. Review the individual question feedback to identify areas for improvement.`;
    }

    const evaluation = await Evaluation.create({
      submission: submissionId,
      exam: exam._id,
      student: studentId,
      teacher: exam.teacher,
      questionEvaluations,
      totalMarksAwarded,
      totalMaxMarks: exam.totalMarks,
      percentage: parseFloat(percentage.toFixed(2)),
      overallStrengths: [...new Set(allStrengths)].slice(0, 5),
      overallAreasOfImprovement: [...new Set(allAreasOfImprovement)].slice(0, 5),
      overallFeedback,
    });

    // Update submission status
    await Submission.findByIdAndUpdate(submissionId, {
      status: 'evaluated',
      evaluatedAt: new Date(),
    });

    return evaluation;
  } catch (error) {
    await Submission.findByIdAndUpdate(submissionId, { status: 'failed' });
    throw error;
  }
};

// @desc  Get evaluation by submission ID
exports.getEvaluation = async (req, res) => {
  try {
    const evaluation = await Evaluation.findOne({ submission: req.params.submissionId })
      .populate('student', 'name email')
      .populate('exam', 'title subject totalMarks')
      .populate('teacher', 'name');
    if (!evaluation) {
      return res.status(404).json({ success: false, message: 'Evaluation not found yet' });
    }
    res.json({ success: true, evaluation });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc  Get all evaluations for student
exports.getMyEvaluations = async (req, res) => {
  try {
    const evaluations = await Evaluation.find({ student: req.user._id })
      .populate('exam', 'title subject totalMarks')
      .sort({ evaluatedAt: -1 });
    res.json({ success: true, evaluations });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc  Teacher updates evaluation notes
exports.reviewEvaluation = async (req, res) => {
  try {
    const { teacherNotes } = req.body;
    const evaluation = await Evaluation.findByIdAndUpdate(
      req.params.id,
      { teacherNotes, isReviewed: true },
      { new: true }
    );
    res.json({ success: true, evaluation });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
