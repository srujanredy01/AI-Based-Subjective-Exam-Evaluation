const Exam = require('../models/Exam');
const Submission = require('../models/Submission');
const Evaluation = require('../models/Evaluation');

// @desc  Create exam
exports.createExam = async (req, res) => {
  try {
    const { title, subject, description, questions, duration, startTime, endTime, isPublic } = req.body;
    const exam = await Exam.create({
      title, subject, description, questions, duration,
      startTime, endTime, isPublic,
      teacher: req.user._id,
      status: 'active',
    });
    res.status(201).json({ success: true, exam });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc  Get all exams (teacher sees own, student sees active)
exports.getExams = async (req, res) => {
  try {
    let query = {};
    if (req.user.role === 'teacher') {
      query.teacher = req.user._id;
    } else {
      query.status = 'active';
      query.isPublic = true;
    }
    const exams = await Exam.find(query)
      .populate('teacher', 'name email')
      .sort({ createdAt: -1 });
    res.json({ success: true, exams });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc  Get single exam
exports.getExam = async (req, res) => {
  try {
    const exam = await Exam.findById(req.params.id).populate('teacher', 'name email');
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' });
    res.json({ success: true, exam });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc  Update exam
exports.updateExam = async (req, res) => {
  try {
    let exam = await Exam.findById(req.params.id);
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' });
    if (exam.teacher.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }
    exam = await Exam.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    res.json({ success: true, exam });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc  Delete exam
exports.deleteExam = async (req, res) => {
  try {
    const exam = await Exam.findById(req.params.id);
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' });
    if (exam.teacher.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }
    await exam.deleteOne();
    res.json({ success: true, message: 'Exam deleted' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc  Get teacher analytics
exports.getAnalytics = async (req, res) => {
  try {
    const exams = await Exam.find({ teacher: req.user._id });
    const examIds = exams.map(e => e._id);
    const submissions = await Submission.find({ exam: { $in: examIds } });
    const evaluations = await Evaluation.find({ exam: { $in: examIds } });

    const avgScore = evaluations.length
      ? (evaluations.reduce((sum, e) => sum + e.percentage, 0) / evaluations.length).toFixed(1)
      : 0;

    const gradeDistribution = { 'A+': 0, A: 0, 'B+': 0, B: 0, C: 0, D: 0, F: 0 };
    evaluations.forEach(e => { if (gradeDistribution[e.grade] !== undefined) gradeDistribution[e.grade]++; });

    res.json({
      success: true,
      analytics: {
        totalExams: exams.length,
        totalSubmissions: submissions.length,
        totalEvaluations: evaluations.length,
        avgScore,
        gradeDistribution,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
