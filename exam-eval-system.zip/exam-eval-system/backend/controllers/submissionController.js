const Submission = require('../models/Submission');
const Exam = require('../models/Exam');
const Evaluation = require('../models/Evaluation');
const { evaluateWithGemini } = require('./evaluationController');

// @desc  Submit exam answers
exports.submitExam = async (req, res) => {
  try {
    const { examId, answers } = req.body;
    const exam = await Exam.findById(examId);
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' });

    // Check if already submitted
    const existing = await Submission.findOne({ exam: examId, student: req.user._id });
    if (existing) {
      return res.status(400).json({ success: false, message: 'Already submitted this exam' });
    }

    const submission = await Submission.create({
      exam: examId,
      student: req.user._id,
      answers,
      status: 'evaluating',
    });

    // Trigger AI evaluation asynchronously
    evaluateWithGemini(submission._id, exam, answers, req.user._id)
      .then(() => console.log(`✅ Evaluation complete for submission ${submission._id}`))
      .catch(err => console.error(`❌ Evaluation failed: ${err.message}`));

    res.status(201).json({ success: true, submission, message: 'Submitted! AI evaluation in progress.' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc  Get student's submissions
exports.getMySubmissions = async (req, res) => {
  try {
    const submissions = await Submission.find({ student: req.user._id })
      .populate('exam', 'title subject totalMarks')
      .sort({ submittedAt: -1 });
    res.json({ success: true, submissions });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc  Get all submissions for teacher
exports.getSubmissionsForTeacher = async (req, res) => {
  try {
    const exams = await Exam.find({ teacher: req.user._id }).select('_id');
    const examIds = exams.map(e => e._id);
    const submissions = await Submission.find({ exam: { $in: examIds } })
      .populate('exam', 'title subject')
      .populate('student', 'name email')
      .sort({ submittedAt: -1 });
    res.json({ success: true, submissions });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc  Get single submission
exports.getSubmission = async (req, res) => {
  try {
    const submission = await Submission.findById(req.params.id)
      .populate('exam')
      .populate('student', 'name email');
    if (!submission) return res.status(404).json({ success: false, message: 'Submission not found' });
    res.json({ success: true, submission });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
