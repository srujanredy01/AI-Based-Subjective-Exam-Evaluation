const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
  createExam, getExams, getExam, updateExam, deleteExam, getAnalytics,
} = require('../controllers/examController');

router.get('/analytics', protect, authorize('teacher'), getAnalytics);
router.route('/')
  .get(protect, getExams)
  .post(protect, authorize('teacher'), createExam);
router.route('/:id')
  .get(protect, getExam)
  .put(protect, authorize('teacher'), updateExam)
  .delete(protect, authorize('teacher'), deleteExam);

module.exports = router;
