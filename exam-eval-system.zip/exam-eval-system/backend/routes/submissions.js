const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
  submitExam, getMySubmissions, getSubmissionsForTeacher, getSubmission,
} = require('../controllers/submissionController');

router.post('/', protect, authorize('student'), submitExam);
router.get('/my', protect, authorize('student'), getMySubmissions);
router.get('/teacher', protect, authorize('teacher'), getSubmissionsForTeacher);
router.get('/:id', protect, getSubmission);

module.exports = router;
