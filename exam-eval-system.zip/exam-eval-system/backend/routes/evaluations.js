const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
  getEvaluation, getMyEvaluations, reviewEvaluation,
} = require('../controllers/evaluationController');

router.get('/my', protect, authorize('student'), getMyEvaluations);
router.get('/submission/:submissionId', protect, getEvaluation);
router.put('/:id/review', protect, authorize('teacher'), reviewEvaluation);

module.exports = router;
