const mongoose = require('mongoose');

const questionSchema = new mongoose.Schema({
  questionText: { type: String, required: true },
  modelAnswer: { type: String, required: true },
  maxMarks: { type: Number, required: true, min: 1 },
  rubric: {
    excellent: { type: String, default: '' },
    good: { type: String, default: '' },
    average: { type: String, default: '' },
    poor: { type: String, default: '' },
  },
});

const examSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  subject: { type: String, required: true, trim: true },
  description: { type: String, default: '' },
  teacher: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  questions: [questionSchema],
  totalMarks: { type: Number, default: 0 },
  duration: { type: Number, default: 60 }, // in minutes
  startTime: { type: Date },
  endTime: { type: Date },
  status: { type: String, enum: ['draft', 'active', 'closed'], default: 'draft' },
  allowedStudents: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  isPublic: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
});

// Auto-calculate total marks
examSchema.pre('save', function (next) {
  this.totalMarks = this.questions.reduce((sum, q) => sum + q.maxMarks, 0);
  next();
});

module.exports = mongoose.model('Exam', examSchema);
