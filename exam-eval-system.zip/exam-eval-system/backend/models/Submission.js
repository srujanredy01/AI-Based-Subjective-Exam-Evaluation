const mongoose = require('mongoose');

const answerSchema = new mongoose.Schema({
  questionId: { type: mongoose.Schema.Types.ObjectId, required: true },
  answerText: { type: String, default: '' },
  answerFile: { type: String, default: '' }, // file path if uploaded
  answerType: { type: String, enum: ['typed', 'uploaded'], default: 'typed' },
});

const submissionSchema = new mongoose.Schema({
  exam: { type: mongoose.Schema.Types.ObjectId, ref: 'Exam', required: true },
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  answers: [answerSchema],
  status: {
    type: String,
    enum: ['submitted', 'evaluating', 'evaluated', 'failed'],
    default: 'submitted',
  },
  submittedAt: { type: Date, default: Date.now },
  evaluatedAt: { type: Date },
});

module.exports = mongoose.model('Submission', submissionSchema);
