const mongoose = require('mongoose');

const questionEvalSchema = new mongoose.Schema({
  questionId: { type: mongoose.Schema.Types.ObjectId },
  questionText: { type: String },
  studentAnswer: { type: String },
  modelAnswer: { type: String },
  marksAwarded: { type: Number, default: 0 },
  maxMarks: { type: Number, default: 0 },
  strengths: [String],
  areasOfImprovement: [String],
  feedback: { type: String, default: '' },
  aiReasoning: { type: String, default: '' },
});

const evaluationSchema = new mongoose.Schema({
  submission: { type: mongoose.Schema.Types.ObjectId, ref: 'Submission', required: true },
  exam: { type: mongoose.Schema.Types.ObjectId, ref: 'Exam', required: true },
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  teacher: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  questionEvaluations: [questionEvalSchema],
  totalMarksAwarded: { type: Number, default: 0 },
  totalMaxMarks: { type: Number, default: 0 },
  percentage: { type: Number, default: 0 },
  grade: { type: String, default: '' },
  overallStrengths: [String],
  overallAreasOfImprovement: [String],
  overallFeedback: { type: String, default: '' },
  aiModel: { type: String, default: 'gemini-1.5-flash' },
  evaluatedAt: { type: Date, default: Date.now },
  isReviewed: { type: Boolean, default: false },
  teacherNotes: { type: String, default: '' },
});

// Calculate grade from percentage
evaluationSchema.pre('save', function (next) {
  const p = this.percentage;
  if (p >= 90) this.grade = 'A+';
  else if (p >= 80) this.grade = 'A';
  else if (p >= 70) this.grade = 'B+';
  else if (p >= 60) this.grade = 'B';
  else if (p >= 50) this.grade = 'C';
  else if (p >= 40) this.grade = 'D';
  else this.grade = 'F';
  next();
});

module.exports = mongoose.model('Evaluation', evaluationSchema);
