import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import API from '../utils/api';

const SubmissionStatusPage = () => {
  const { submissionId } = useParams();
  const navigate = useNavigate();
  const [status, setStatus] = useState('evaluating');
  const [dots, setDots] = useState('');

  useEffect(() => {
    const dotInterval = setInterval(() => {
      setDots(p => p.length >= 3 ? '' : p + '.');
    }, 500);

    const poll = async () => {
      try {
        const { data } = await API.get(`/submissions/${submissionId}`);
        const s = data.submission.status;
        setStatus(s);
        if (s === 'evaluated') {
          clearInterval(interval);
          clearInterval(dotInterval);
          // Get evaluation and navigate
          const evRes = await API.get(`/evaluations/submission/${submissionId}`);
          navigate(`/evaluation/${evRes.data.evaluation._id}`, { replace: true });
        } else if (s === 'failed') {
          clearInterval(interval);
          clearInterval(dotInterval);
        }
      } catch {}
    };

    const interval = setInterval(poll, 3000);
    poll();

    return () => { clearInterval(interval); clearInterval(dotInterval); };
  }, [submissionId, navigate]);

  const steps = [
    { label: 'Answer submitted', done: true },
    { label: 'AI analyzing responses', done: status !== 'submitted' },
    { label: 'Generating feedback', done: status === 'evaluated' },
    { label: 'Report ready', done: status === 'evaluated' },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center px-4">
      <div className="text-center max-w-md">
        {status === 'failed' ? (
          <>
            <div className="text-6xl mb-6">❌</div>
            <h2 className="text-2xl font-bold mb-3">Evaluation Failed</h2>
            <p className="text-slate-400 mb-6">Something went wrong with the AI evaluation. Please contact your teacher.</p>
          </>
        ) : (
          <>
            {/* AI Animation */}
            <div className="relative w-24 h-24 mx-auto mb-8">
              <div className="absolute inset-0 bg-blue-500/20 rounded-full animate-ping" />
              <div className="absolute inset-2 bg-blue-500/30 rounded-full animate-ping" style={{ animationDelay: '0.2s' }} />
              <div className="relative w-24 h-24 bg-gradient-to-br from-blue-500 to-violet-600 rounded-full flex items-center justify-center text-4xl">
                🧠
              </div>
            </div>

            <h2 className="text-2xl font-bold mb-2">AI is evaluating{dots}</h2>
            <p className="text-slate-400 mb-8">Gemini AI is analyzing your answers against the model responses and rubrics.</p>

            {/* Steps */}
            <div className="space-y-3 text-left bg-slate-900 border border-slate-800 rounded-2xl p-5 mb-8">
              {steps.map(({ label, done }, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${done ? 'bg-green-500' : 'bg-slate-700'}`}>
                    {done ? <span className="text-xs">✓</span> : <span className="text-xs text-slate-500">{i + 1}</span>}
                  </div>
                  <span className={`text-sm ${done ? 'text-green-400' : 'text-slate-400'}`}>{label}</span>
                  {!done && i === steps.findIndex(s => !s.done) && (
                    <svg className="animate-spin w-4 h-4 text-blue-500 ml-auto" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                  )}
                </div>
              ))}
            </div>

            <p className="text-slate-500 text-sm">This usually takes 10–30 seconds. Please wait...</p>
          </>
        )}
      </div>
    </div>
  );
};

export default SubmissionStatusPage;
