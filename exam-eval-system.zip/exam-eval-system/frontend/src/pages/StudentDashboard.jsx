import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import API from '../utils/api';
import { toast } from 'react-toastify';

const gradeColor = (g) => {
  if (!g) return 'text-slate-400';
  if (g === 'A+' || g === 'A') return 'text-green-400';
  if (g === 'B+' || g === 'B') return 'text-blue-400';
  if (g === 'C') return 'text-yellow-400';
  return 'text-red-400';
};

const CountdownTimer = ({ endTime }) => {
  const [time, setTime] = useState('');
  useEffect(() => {
    const tick = () => {
      const diff = new Date(endTime) - new Date();
      if (diff <= 0) { setTime('Expired'); return; }
      const h = Math.floor(diff / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setTime(`${h}h ${m}m ${s}s`);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [endTime]);
  return <span className="text-orange-400 font-mono text-sm">{time}</span>;
};

const StudentDashboard = () => {
  const { user, logout } = useAuth();
  const [tab, setTab] = useState('exams');
  const [exams, setExams] = useState([]);
  const [evaluations, setEvaluations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [eRes, evRes] = await Promise.all([
          API.get('/exams'),
          API.get('/evaluations/my'),
        ]);
        setExams(eRes.data.exams);
        setEvaluations(evRes.data.evaluations);
      } catch { toast.error('Failed to load data'); }
      setLoading(false);
    };
    fetchData();
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Navbar */}
      <nav className="bg-slate-900 border-b border-slate-800 px-8 py-4 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-violet-600 rounded-lg flex items-center justify-center text-sm font-bold">E</div>
          <span className="font-bold">ExamEval<span className="text-blue-400">AI</span></span>
        </div>
        <div className="flex items-center gap-6">
          {[{ id: 'exams', label: 'Available Exams' }, { id: 'results', label: 'My Results' }].map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`text-sm font-medium pb-0.5 border-b-2 transition ${tab === t.id ? 'border-blue-500 text-white' : 'border-transparent text-slate-400 hover:text-white'}`}>
              {t.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-violet-600 rounded-full flex items-center justify-center text-xs font-bold">
              {user?.name?.[0]?.toUpperCase()}
            </div>
            <span className="text-sm text-slate-300">{user?.name}</span>
          </div>
          <button onClick={logout} className="text-sm text-red-400 hover:text-red-300 transition">Logout</button>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-8 py-8">
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <svg className="animate-spin w-8 h-8 text-blue-500" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
            </svg>
          </div>
        ) : tab === 'exams' ? (
          <div className="animate-fade-in">
            <div className="mb-6">
              <h1 className="text-2xl font-bold">Available Exams</h1>
              <p className="text-slate-400 mt-1">Select an exam to begin your submission</p>
            </div>
            {exams.length === 0 ? (
              <div className="text-center py-20 text-slate-400">
                <div className="text-5xl mb-4">📚</div>
                <p className="text-lg font-medium">No exams available</p>
                <p className="text-sm mt-1">Check back later for new exams</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
                {exams.map(exam => {
                  const alreadyTaken = evaluations.some(e => e.exam?._id === exam._id);
                  return (
                    <div key={exam._id} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:border-blue-500/50 transition group">
                      <div className="flex items-start justify-between mb-3">
                        <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center text-xl">📋</div>
                        {alreadyTaken && (
                          <span className="text-xs bg-green-500/20 text-green-400 px-2 py-0.5 rounded-full">Completed</span>
                        )}
                      </div>
                      <h3 className="font-semibold mb-1 group-hover:text-blue-400 transition">{exam.title}</h3>
                      <p className="text-sm text-slate-400 mb-3">{exam.subject}</p>
                      <div className="space-y-1.5 text-xs text-slate-500 mb-4">
                        <div className="flex justify-between">
                          <span>Questions</span><span className="text-slate-300">{exam.questions?.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Total Marks</span><span className="text-slate-300">{exam.totalMarks}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Duration</span><span className="text-slate-300">{exam.duration} min</span>
                        </div>
                        {exam.endTime && (
                          <div className="flex justify-between">
                            <span>Time Left</span><CountdownTimer endTime={exam.endTime} />
                          </div>
                        )}
                      </div>
                      {alreadyTaken ? (
                        <Link to={`/results/${exam._id}`} className="block w-full text-center py-2 text-sm border border-blue-500/50 text-blue-400 rounded-xl hover:bg-blue-500/10 transition">
                          View Results →
                        </Link>
                      ) : (
                        <Link to={`/exam/${exam._id}`} className="block w-full text-center py-2 text-sm bg-blue-600 hover:bg-blue-500 rounded-xl transition font-medium">
                          Start Exam →
                        </Link>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ) : (
          <div className="animate-fade-in">
            <div className="mb-6">
              <h1 className="text-2xl font-bold">My Results</h1>
              <p className="text-slate-400 mt-1">View your AI-evaluated exam results and feedback</p>
            </div>
            {evaluations.length === 0 ? (
              <div className="text-center py-20 text-slate-400">
                <div className="text-5xl mb-4">📊</div>
                <p className="text-lg font-medium">No results yet</p>
                <p className="text-sm mt-1">Complete an exam to see your results here</p>
              </div>
            ) : (
              <div className="space-y-4">
                {evaluations.map(ev => (
                  <div key={ev._id} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`text-3xl font-bold ${gradeColor(ev.grade)}`}>{ev.grade}</div>
                      <div>
                        <p className="font-semibold">{ev.exam?.title}</p>
                        <p className="text-sm text-slate-400">{ev.exam?.subject}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-8 text-sm">
                      <div className="text-center">
                        <p className="font-bold text-lg">{ev.totalMarksAwarded}/{ev.totalMaxMarks}</p>
                        <p className="text-slate-500 text-xs">Score</p>
                      </div>
                      <div className="text-center">
                        <p className="font-bold text-lg">{ev.percentage.toFixed(1)}%</p>
                        <p className="text-slate-500 text-xs">Percentage</p>
                      </div>
                      <Link to={`/evaluation/${ev._id}`}
                        className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-xl text-sm transition">
                        Full Report →
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default StudentDashboard;
