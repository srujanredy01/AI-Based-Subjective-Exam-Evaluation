import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import API from '../utils/api';

const gradeColor = { 'A+': 'text-emerald-400', A: 'text-green-400', 'B+': 'text-blue-400', B: 'text-cyan-400', C: 'text-yellow-400', D: 'text-orange-400', F: 'text-red-400' };

const EvaluationReportPage = () => {
  const { evalId } = useParams();
  const [evaluation, setEvaluation] = useState(null);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    API.get(`/evaluations/submission/${evalId}`)
      .catch(() => API.get(`/evaluations/my`).then(r => ({
        data: { evaluation: r.data.evaluations?.find(e => e._id === evalId) }
      })))
      .catch(() => {})
      .finally(() => setLoading(false));

    // Try direct fetch by submission id first, fallback
    const load = async () => {
      try {
        // evalId might be evaluation _id, try my evaluations and find it
        const { data } = await API.get('/evaluations/my');
        const ev = data.evaluations.find(e => e._id === evalId);
        if (ev) {
          // Get full details
          const { data: full } = await API.get(`/evaluations/submission/${ev.submission || ev._id}`);
          setEvaluation(full.evaluation);
        }
      } catch {
        try {
          const { data } = await API.get(`/evaluations/submission/${evalId}`);
          setEvaluation(data.evaluation);
        } catch {}
      }
      setLoading(false);
    };
    load();
  }, [evalId]);

  const handlePrint = () => window.print();

  if (loading) return (
    <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">
      <svg className="animate-spin w-8 h-8 text-blue-500" fill="none" viewBox="0 0 24 24">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
      </svg>
    </div>
  );

  if (!evaluation) return (
    <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">
      <div className="text-center">
        <p className="text-2xl mb-4">📊</p>
        <p className="text-slate-400">Report not found</p>
        <Link to="/student" className="text-blue-400 mt-4 block">← Back to Dashboard</Link>
      </div>
    </div>
  );

  const pct = evaluation.percentage;
  const circumference = 2 * Math.PI * 45;
  const dashOffset = circumference - (pct / 100) * circumference;

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <header className="bg-slate-900 border-b border-slate-800 px-8 py-4 print:hidden">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to="/student" className="text-slate-400 hover:text-white transition">← Dashboard</Link>
            <span className="text-slate-700">/</span>
            <span className="text-slate-300">Evaluation Report</span>
          </div>
          <button onClick={handlePrint}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-xl text-sm transition flex items-center gap-2">
            📄 Download Report
          </button>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-8 py-8 animate-fade-in">
        {/* Report header */}
        <div className="bg-gradient-to-r from-blue-600/20 to-violet-600/20 border border-blue-500/30 rounded-3xl p-8 mb-6 text-center">
          <div className="text-sm text-blue-400 font-medium mb-2">🤖 AI Evaluation Report</div>
          <h1 className="text-3xl font-bold mb-1">{evaluation.exam?.title}</h1>
          <p className="text-slate-400">{evaluation.exam?.subject} · {evaluation.student?.name}</p>
        </div>

        {/* Score cards */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          {/* Circular score */}
          <div className="col-span-1 bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col items-center">
            <svg width="110" height="110" viewBox="0 0 110 110">
              <circle cx="55" cy="55" r="45" fill="none" stroke="#1e293b" strokeWidth="8" />
              <circle cx="55" cy="55" r="45" fill="none" stroke="url(#grad)" strokeWidth="8"
                strokeLinecap="round" strokeDasharray={circumference} strokeDashoffset={dashOffset}
                transform="rotate(-90 55 55)" />
              <defs>
                <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="#8b5cf6" />
                </linearGradient>
              </defs>
              <text x="55" y="50" textAnchor="middle" fill="white" fontSize="18" fontWeight="bold">{pct.toFixed(0)}%</text>
              <text x="55" y="66" textAnchor="middle" fill="#94a3b8" fontSize="10">Score</text>
            </svg>
          </div>

          {[
            { label: 'Marks', value: `${evaluation.totalMarksAwarded}/${evaluation.totalMaxMarks}` },
            { label: 'Grade', value: evaluation.grade, cls: gradeColor[evaluation.grade] },
            { label: 'Evaluated By', value: 'Gemini AI', cls: 'text-violet-400 text-sm' },
          ].map(({ label, value, cls }) => (
            <div key={label} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col items-center justify-center">
              <p className={`text-3xl font-bold ${cls || 'text-blue-400'}`}>{value}</p>
              <p className="text-slate-500 text-xs mt-1">{label}</p>
            </div>
          ))}
        </div>

        {/* AI Feedback */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 mb-6">
          <h3 className="font-semibold mb-3 flex items-center gap-2">🤖 <span>AI Overall Feedback</span></h3>
          <p className="text-slate-300 leading-relaxed">{evaluation.overallFeedback}</p>
        </div>

        {/* Strengths & improvements */}
        <div className="grid grid-cols-2 gap-5 mb-6">
          <div className="bg-green-500/5 border border-green-500/20 rounded-2xl p-5">
            <h4 className="font-semibold text-green-400 mb-4 flex items-center gap-2">✓ Strengths</h4>
            <ul className="space-y-2.5">
              {evaluation.overallStrengths?.map((s, i) => (
                <li key={i} className="flex items-start gap-2.5 text-sm text-slate-300">
                  <span className="text-green-500 mt-0.5 flex-shrink-0">•</span>{s}
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-amber-500/5 border border-amber-500/20 rounded-2xl p-5">
            <h4 className="font-semibold text-amber-400 mb-4 flex items-center gap-2">→ Areas to Improve</h4>
            <ul className="space-y-2.5">
              {evaluation.overallAreasOfImprovement?.map((a, i) => (
                <li key={i} className="flex items-start gap-2.5 text-sm text-slate-300">
                  <span className="text-amber-500 mt-0.5 flex-shrink-0">•</span>{a}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Question breakdown */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-800">
            <h3 className="font-semibold">Question-by-Question Breakdown</h3>
          </div>
          {evaluation.questionEvaluations?.map((qe, i) => (
            <div key={i} className="border-b border-slate-800/50 last:border-none">
              <button
                onClick={() => setExpanded(expanded === i ? null : i)}
                className="w-full flex items-center justify-between px-6 py-4 hover:bg-slate-800/30 transition text-left"
              >
                <div className="flex items-center gap-3">
                  <span className="text-blue-400 text-sm font-medium w-6">Q{i + 1}</span>
                  <span className="text-sm text-slate-300 line-clamp-1">{qe.questionText}</span>
                </div>
                <div className="flex items-center gap-4 flex-shrink-0">
                  <span className="font-bold text-sm">
                    <span className="text-blue-400">{qe.marksAwarded}</span>
                    <span className="text-slate-600">/{qe.maxMarks}</span>
                  </span>
                  <div className="w-20 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 rounded-full" style={{ width: `${(qe.marksAwarded / qe.maxMarks) * 100}%` }} />
                  </div>
                  <span className="text-slate-400 text-xs">{expanded === i ? '▲' : '▼'}</span>
                </div>
              </button>
              {expanded === i && (
                <div className="px-6 pb-4 space-y-3 animate-slide-up">
                  <div className="bg-slate-800/50 rounded-xl p-3 text-sm text-slate-400">
                    <span className="text-slate-500 text-xs block mb-1">Your Answer</span>
                    {qe.studentAnswer || <em>No answer provided</em>}
                  </div>
                  <div className="bg-blue-500/5 border border-blue-500/20 rounded-xl p-3 text-sm text-slate-300">
                    <span className="text-blue-400 text-xs block mb-1">AI Feedback</span>
                    {qe.feedback}
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-green-400 text-xs block mb-1">Strengths</span>
                      <ul className="space-y-1">{qe.strengths?.map((s, j) => <li key={j} className="text-xs text-slate-400 flex gap-1.5"><span className="text-green-500">•</span>{s}</li>)}</ul>
                    </div>
                    <div>
                      <span className="text-yellow-400 text-xs block mb-1">Improve</span>
                      <ul className="space-y-1">{qe.areasOfImprovement?.map((a, j) => <li key={j} className="text-xs text-slate-400 flex gap-1.5"><span className="text-yellow-500">•</span>{a}</li>)}</ul>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="text-center text-slate-600 text-xs mt-6">
          Evaluated by Gemini AI · {new Date(evaluation.evaluatedAt).toLocaleString()}
        </div>
      </div>
    </div>
  );
};

export default EvaluationReportPage;
