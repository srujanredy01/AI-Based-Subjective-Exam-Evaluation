import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import API from '../utils/api';
import { toast } from 'react-toastify';
import CreateExamModal from '../components/dashboard/CreateExamModal';
import SubmissionsTable from '../components/dashboard/SubmissionsTable';
import AnalyticsSection from '../components/dashboard/AnalyticsSection';
import EvalReviewModal from '../components/dashboard/EvalReviewModal';

const NAV = [
  { id: 'exams', label: 'Exams', icon: '📋' },
  { id: 'submissions', label: 'Submissions', icon: '📤' },
  { id: 'analytics', label: 'Analytics', icon: '📊' },
];

const TeacherDashboard = () => {
  const { user, logout } = useAuth();
  const [active, setActive] = useState('exams');
  const [exams, setExams] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [reviewSub, setReviewSub] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  useEffect(() => { fetchAll(); }, []);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [eRes, sRes, aRes] = await Promise.all([
        API.get('/exams'),
        API.get('/submissions/teacher'),
        API.get('/exams/analytics'),
      ]);
      setExams(eRes.data.exams);
      setSubmissions(sRes.data.submissions);
      setAnalytics(aRes.data.analytics);
    } catch (err) {
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const deleteExam = async (id) => {
    if (!window.confirm('Delete this exam?')) return;
    try {
      await API.delete(`/exams/${id}`);
      setExams(prev => prev.filter(e => e._id !== id));
      toast.success('Exam deleted');
    } catch { toast.error('Failed to delete'); }
  };

  const statusBadge = (status) => {
    const map = { active: 'bg-green-500/20 text-green-400', draft: 'bg-yellow-500/20 text-yellow-400', closed: 'bg-slate-500/20 text-slate-400' };
    return <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${map[status] || ''}`}>{status}</span>;
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-16'} bg-slate-900 border-r border-slate-800 flex flex-col transition-all duration-300 fixed h-full z-30`}>
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          {sidebarOpen && (
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 bg-gradient-to-br from-blue-500 to-violet-600 rounded-lg flex items-center justify-center text-xs font-bold">E</div>
              <span className="font-bold text-sm">ExamEvalAI</span>
            </div>
          )}
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-slate-400 hover:text-white p-1">
            {sidebarOpen ? '◀' : '▶'}
          </button>
        </div>

        <nav className="flex-1 p-3 space-y-1">
          {NAV.map(n => (
            <button
              key={n.id}
              onClick={() => setActive(n.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition ${
                active === n.id ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <span className="text-lg">{n.icon}</span>
              {sidebarOpen && n.label}
            </button>
          ))}
        </nav>

        <div className="p-3 border-t border-slate-800">
          <div className={`flex items-center gap-3 px-3 py-2 mb-2 ${!sidebarOpen && 'justify-center'}`}>
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-violet-600 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0">
              {user?.name?.[0]?.toUpperCase()}
            </div>
            {sidebarOpen && (
              <div className="min-w-0">
                <p className="text-sm font-medium truncate">{user?.name}</p>
                <p className="text-xs text-slate-400 truncate">Teacher</p>
              </div>
            )}
          </div>
          <button onClick={logout} className={`w-full flex items-center gap-2 px-3 py-2 text-sm text-red-400 hover:bg-red-500/10 rounded-xl transition ${!sidebarOpen && 'justify-center'}`}>
            <span>🚪</span>{sidebarOpen && 'Logout'}
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className={`flex-1 ${sidebarOpen ? 'ml-64' : 'ml-16'} transition-all duration-300`}>
        <header className="bg-slate-900/80 backdrop-blur border-b border-slate-800 px-8 py-4 sticky top-0 z-20">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold capitalize">{active}</h1>
              <p className="text-slate-400 text-sm">Welcome back, {user?.name}</p>
            </div>
            {active === 'exams' && (
              <button
                onClick={() => setShowCreate(true)}
                className="bg-blue-600 hover:bg-blue-500 px-5 py-2 rounded-xl text-sm font-medium transition flex items-center gap-2"
              >
                + Create Exam
              </button>
            )}
          </div>
        </header>

        <div className="p-8">
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <svg className="animate-spin w-8 h-8 mx-auto text-blue-500 mb-3" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                </svg>
                <p className="text-slate-400">Loading...</p>
              </div>
            </div>
          ) : (
            <>
              {active === 'exams' && (
                <div className="animate-fade-in">
                  {/* Stats row */}
                  <div className="grid grid-cols-3 gap-4 mb-8">
                    {[
                      { label: 'Total Exams', value: exams.length, icon: '📋' },
                      { label: 'Submissions', value: submissions.length, icon: '📤' },
                      { label: 'Evaluations', value: analytics?.totalEvaluations || 0, icon: '✅' },
                    ].map(({ label, value, icon }) => (
                      <div key={label} className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                        <div className="flex items-center justify-between mb-2">
                          <p className="text-slate-400 text-sm">{label}</p>
                          <span className="text-2xl">{icon}</span>
                        </div>
                        <p className="text-3xl font-bold">{value}</p>
                      </div>
                    ))}
                  </div>

                  {/* Exams table */}
                  {exams.length === 0 ? (
                    <div className="text-center py-20 text-slate-400">
                      <div className="text-5xl mb-4">📋</div>
                      <p className="text-lg font-medium mb-2">No exams yet</p>
                      <p className="text-sm">Create your first exam to get started</p>
                    </div>
                  ) : (
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b border-slate-800 text-slate-400 text-sm">
                            <th className="text-left px-6 py-4 font-medium">Title</th>
                            <th className="text-left px-6 py-4 font-medium">Subject</th>
                            <th className="text-left px-6 py-4 font-medium">Questions</th>
                            <th className="text-left px-6 py-4 font-medium">Marks</th>
                            <th className="text-left px-6 py-4 font-medium">Status</th>
                            <th className="text-left px-6 py-4 font-medium">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {exams.map(exam => (
                            <tr key={exam._id} className="border-b border-slate-800/50 hover:bg-slate-800/30 transition">
                              <td className="px-6 py-4 font-medium">{exam.title}</td>
                              <td className="px-6 py-4 text-slate-400">{exam.subject}</td>
                              <td className="px-6 py-4 text-slate-400">{exam.questions?.length || 0}</td>
                              <td className="px-6 py-4 text-slate-400">{exam.totalMarks}</td>
                              <td className="px-6 py-4">{statusBadge(exam.status)}</td>
                              <td className="px-6 py-4">
                                <button onClick={() => deleteExam(exam._id)} className="text-red-400 hover:text-red-300 text-sm">Delete</button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}

              {active === 'submissions' && (
                <SubmissionsTable submissions={submissions} onReview={setReviewSub} />
              )}

              {active === 'analytics' && analytics && (
                <AnalyticsSection analytics={analytics} />
              )}
            </>
          )}
        </div>
      </main>

      {showCreate && (
        <CreateExamModal
          onClose={() => setShowCreate(false)}
          onCreated={(exam) => { setExams(prev => [exam, ...prev]); setShowCreate(false); toast.success('Exam created!'); }}
        />
      )}

      {reviewSub && (
        <EvalReviewModal submission={reviewSub} onClose={() => setReviewSub(null)} />
      )}
    </div>
  );
};

export default TeacherDashboard;
