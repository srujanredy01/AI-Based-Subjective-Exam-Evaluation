import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import API from '../utils/api';
import { toast } from 'react-toastify';

const ExamPage = () => {
  const { examId } = useParams();
  const navigate = useNavigate();
  const [exam, setExam] = useState(null);
  const [loading, setLoading] = useState(true);
  const [answers, setAnswers] = useState({});
  const [answerTypes, setAnswerTypes] = useState({});
  const [dragOver, setDragOver] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentQ, setCurrentQ] = useState(0);
  const fileRefs = useRef({});

  useEffect(() => {
    API.get(`/exams/${examId}`).then(({ data }) => {
      setExam(data.exam);
      const initTypes = {};
      data.exam.questions.forEach(q => { initTypes[q._id] = 'typed'; });
      setAnswerTypes(initTypes);
    }).catch(() => toast.error('Failed to load exam')).finally(() => setLoading(false));
  }, [examId]);

  useEffect(() => {
    if (!exam) return;
    const answered = Object.values(answers).filter(a => a?.trim()).length;
    setProgress((answered / exam.questions.length) * 100);
  }, [answers, exam]);

  const handleFile = (qId, file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setAnswers(p => ({ ...p, [qId]: `[File: ${file.name}]` }));
    reader.readAsDataURL(file);
  };

  const handleSubmit = async () => {
    if (!window.confirm('Submit all answers? This cannot be undone.')) return;
    setSubmitting(true);
    try {
      const formattedAnswers = exam.questions.map(q => ({
        questionId: q._id,
        answerText: answers[q._id] || '',
        answerType: answerTypes[q._id] || 'typed',
      }));
      const { data } = await API.post('/submissions', { examId, answers: formattedAnswers });
      toast.success('Submitted! AI is evaluating your answers...');
      navigate(`/submission/${data.submission._id}`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Submission failed');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">
      <svg className="animate-spin w-8 h-8 text-blue-500" fill="none" viewBox="0 0 24 24">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
      </svg>
    </div>
  );

  if (!exam) return <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">Exam not found</div>;

  const q = exam.questions[currentQ];

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Header */}
      <header className="bg-slate-900 border-b border-slate-800 px-8 py-4 sticky top-0 z-20">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="font-bold text-lg">{exam.title}</h1>
            <p className="text-slate-400 text-sm">{exam.subject} · {exam.questions.length} questions · {exam.totalMarks} marks</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-slate-400">Progress</p>
            <p className="font-bold text-blue-400">{Math.round(progress)}%</p>
          </div>
        </div>
        {/* Progress bar */}
        <div className="max-w-4xl mx-auto mt-3">
          <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-blue-500 to-violet-500 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }} />
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-8 py-8 flex gap-8">
        {/* Question navigation sidebar */}
        <div className="w-48 flex-shrink-0">
          <p className="text-xs text-slate-400 font-medium mb-3 uppercase tracking-wider">Questions</p>
          <div className="grid grid-cols-4 gap-1.5">
            {exam.questions.map((question, i) => (
              <button key={i} onClick={() => setCurrentQ(i)}
                className={`w-9 h-9 rounded-lg text-xs font-medium transition ${
                  i === currentQ ? 'bg-blue-600 text-white' :
                  answers[question._id]?.trim() ? 'bg-green-500/20 text-green-400 border border-green-500/30' :
                  'bg-slate-800 text-slate-400 hover:bg-slate-700'
                }`}>
                {i + 1}
              </button>
            ))}
          </div>
          <div className="mt-4 space-y-2 text-xs">
            <div className="flex items-center gap-2"><div className="w-3 h-3 bg-blue-600 rounded" /><span className="text-slate-400">Current</span></div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 bg-green-500/30 border border-green-500/50 rounded" /><span className="text-slate-400">Answered</span></div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 bg-slate-800 rounded" /><span className="text-slate-400">Pending</span></div>
          </div>
        </div>

        {/* Question area */}
        <div className="flex-1 animate-fade-in" key={currentQ}>
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 mb-4">
            <div className="flex items-center justify-between mb-4">
              <span className="text-blue-400 text-sm font-medium">Question {currentQ + 1} of {exam.questions.length}</span>
              <span className="text-slate-400 text-sm">{q.maxMarks} marks</span>
            </div>
            <p className="text-white text-base leading-relaxed">{q.questionText}</p>
          </div>

          {/* Answer mode toggle */}
          <div className="flex gap-2 mb-4">
            {['typed', 'uploaded'].map(type => (
              <button key={type} onClick={() => setAnswerTypes(p => ({ ...p, [q._id]: type }))}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition ${
                  answerTypes[q._id] === type ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                }`}>
                {type === 'typed' ? '⌨️ Type Answer' : '📄 Upload Sheet'}
              </button>
            ))}
          </div>

          {answerTypes[q._id] === 'typed' ? (
            <textarea
              className="w-full h-48 bg-slate-900 border border-slate-700 rounded-2xl px-5 py-4 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition resize-none leading-relaxed"
              placeholder="Type your answer here..."
              value={answers[q._id] || ''}
              onChange={e => setAnswers(p => ({ ...p, [q._id]: e.target.value }))}
            />
          ) : (
            <div
              onDragOver={e => { e.preventDefault(); setDragOver(p => ({ ...p, [q._id]: true })); }}
              onDragLeave={() => setDragOver(p => ({ ...p, [q._id]: false }))}
              onDrop={e => { e.preventDefault(); setDragOver(p => ({ ...p, [q._id]: false })); handleFile(q._id, e.dataTransfer.files[0]); }}
              onClick={() => fileRefs.current[q._id]?.click()}
              className={`h-48 rounded-2xl border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition ${
                dragOver[q._id] ? 'border-blue-500 bg-blue-500/10' :
                answers[q._id] ? 'border-green-500/50 bg-green-500/5' :
                'border-slate-700 hover:border-slate-600'
              }`}
            >
              {answers[q._id] ? (
                <>
                  <div className="text-4xl mb-2">✅</div>
                  <p className="text-green-400 font-medium">{answers[q._id]}</p>
                  <p className="text-slate-500 text-sm mt-1">Click to replace</p>
                </>
              ) : (
                <>
                  <div className="text-4xl mb-2">📤</div>
                  <p className="text-slate-300 font-medium">Drag & drop or click to upload</p>
                  <p className="text-slate-500 text-sm mt-1">PDF, JPG, PNG accepted</p>
                </>
              )}
              <input
                type="file"
                accept=".pdf,.jpg,.jpeg,.png"
                className="hidden"
                ref={el => fileRefs.current[q._id] = el}
                onChange={e => handleFile(q._id, e.target.files[0])}
              />
            </div>
          )}

          {/* Navigation */}
          <div className="flex items-center justify-between mt-6">
            <button onClick={() => setCurrentQ(p => Math.max(0, p - 1))} disabled={currentQ === 0}
              className="px-5 py-2.5 border border-slate-700 hover:border-slate-500 rounded-xl text-sm transition disabled:opacity-30">
              ← Previous
            </button>
            {currentQ < exam.questions.length - 1 ? (
              <button onClick={() => setCurrentQ(p => p + 1)}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 rounded-xl text-sm font-medium transition">
                Next →
              </button>
            ) : (
              <button onClick={handleSubmit} disabled={submitting}
                className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-500 hover:to-violet-500 rounded-xl text-sm font-medium transition disabled:opacity-50 flex items-center gap-2">
                {submitting ? (
                  <>
                    <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    Submitting...
                  </>
                ) : '✓ Submit Exam'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExamPage;
