import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const stats = [
  { value: '50K+', label: 'Exams Evaluated' },
  { value: '2K+', label: 'Teachers' },
  { value: '98%', label: 'Accuracy Rate' },
  { value: '10x', label: 'Faster Grading' },
];

const features = [
  {
    icon: '🧠',
    title: 'AI-Powered Evaluation',
    desc: 'Gemini AI analyzes student answers against model answers and rubrics with remarkable precision.',
  },
  {
    icon: '⚡',
    title: 'Instant Results',
    desc: 'Get detailed scores, strengths, and improvement areas within seconds of submission.',
  },
  {
    icon: '📊',
    title: 'Deep Analytics',
    desc: 'Track performance trends, grade distributions, and class-wide insights on your dashboard.',
  },
  {
    icon: '📝',
    title: 'Flexible Submissions',
    desc: 'Students can type answers or upload scanned sheets — the AI evaluates both accurately.',
  },
  {
    icon: '🎯',
    title: 'Rubric-Based Grading',
    desc: 'Define custom rubrics per question to align AI evaluation with your exact expectations.',
  },
  {
    icon: '🔒',
    title: 'Secure & Private',
    desc: 'JWT authentication, encrypted data, and role-based access keep your exams secure.',
  },
];

const LandingPage = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handler);
    return () => window.removeEventListener('scroll', handler);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-white overflow-x-hidden">
      {/* Navbar */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-slate-900/95 backdrop-blur shadow-lg' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-violet-600 rounded-lg flex items-center justify-center text-sm font-bold">E</div>
            <span className="font-bold text-xl tracking-tight">ExamEval<span className="text-blue-400">AI</span></span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm text-slate-300">
            <a href="#features" className="hover:text-white transition">Features</a>
            <a href="#stats" className="hover:text-white transition">Pricing</a>
            <a href="#features" className="hover:text-white transition">About</a>
          </div>
          <div className="flex items-center gap-3">
            <Link to="/login" className="text-sm text-slate-300 hover:text-white transition px-4 py-2">Login</Link>
            <Link to="/register" className="text-sm bg-blue-600 hover:bg-blue-500 px-5 py-2 rounded-lg font-medium transition">
              Get Started
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center px-6 pt-20">
        {/* Background glow */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-blue-600/10 rounded-full blur-3xl" />
          <div className="absolute top-1/3 left-1/4 w-[400px] h-[400px] bg-violet-600/10 rounded-full blur-3xl" />
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.03) 1px, transparent 0)',
            backgroundSize: '40px 40px'
          }} />
        </div>

        <div className="relative max-w-5xl mx-auto text-center animate-fade-in">
          <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 rounded-full px-4 py-1.5 text-blue-400 text-sm font-medium mb-8">
            <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse-slow" />
            Powered by Gemini AI
          </div>

          <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6" style={{ fontFamily: 'Syne, sans-serif' }}>
            Transform Your
            <span className="block bg-gradient-to-r from-blue-400 via-violet-400 to-cyan-400 bg-clip-text text-transparent">
              Exam Grading
            </span>
            with AI
          </h1>

          <p className="text-xl text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed">
            Evaluate subjective answers instantly with AI precision. Get detailed feedback,
            scores, and insights — empowering teachers and helping students grow.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/register" className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-500 hover:to-violet-500 px-8 py-4 rounded-xl font-semibold text-lg transition shadow-lg shadow-blue-500/25">
              Start For Free →
            </Link>
            <Link to="/login" className="w-full sm:w-auto border border-slate-700 hover:border-slate-500 px-8 py-4 rounded-xl font-semibold text-lg transition text-slate-300">
              Sign In
            </Link>
          </div>

          {/* Hero Preview Card */}
          <div className="mt-16 max-w-3xl mx-auto bg-slate-800/50 border border-slate-700/50 rounded-2xl p-6 text-left backdrop-blur">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <div className="w-3 h-3 rounded-full bg-yellow-500" />
                <div className="w-3 h-3 rounded-full bg-green-500" />
              </div>
              <span className="text-xs text-slate-500 font-mono">AI Evaluation Report</span>
            </div>
            <div className="grid grid-cols-3 gap-4 mb-4">
              {[['Score', '87/100'], ['Grade', 'A'], ['Time', '0.8s']].map(([k, v]) => (
                <div key={k} className="bg-slate-900/80 rounded-xl p-3 text-center">
                  <div className="text-2xl font-bold text-blue-400">{v}</div>
                  <div className="text-xs text-slate-500 mt-1">{k}</div>
                </div>
              ))}
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex items-start gap-2"><span className="text-green-400">✓</span><span className="text-slate-300">Strong understanding of core concepts with excellent examples</span></div>
              <div className="flex items-start gap-2"><span className="text-yellow-400">→</span><span className="text-slate-300">Could elaborate more on the practical applications section</span></div>
              <div className="flex items-start gap-2"><span className="text-blue-400">💡</span><span className="text-slate-300">Overall well-structured response demonstrating solid knowledge</span></div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section id="stats" className="py-20 px-6">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
          {stats.map(({ value, label }) => (
            <div key={label} className="text-center bg-slate-800/40 border border-slate-700/50 rounded-2xl p-6">
              <div className="text-4xl font-bold text-blue-400 mb-2" style={{ fontFamily: 'Syne' }}>{value}</div>
              <div className="text-slate-400 text-sm">{label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4" style={{ fontFamily: 'Syne' }}>
              Everything You Need
            </h2>
            <p className="text-slate-400 text-lg max-w-xl mx-auto">
              A complete platform for modern, AI-enhanced exam evaluation.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map(({ icon, title, desc }) => (
              <div key={title} className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-6 hover:border-blue-500/50 hover:bg-slate-800/70 transition group">
                <div className="text-3xl mb-4">{icon}</div>
                <h3 className="text-lg font-semibold mb-2 group-hover:text-blue-400 transition">{title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6">
        <div className="max-w-3xl mx-auto text-center bg-gradient-to-r from-blue-600/20 to-violet-600/20 border border-blue-500/30 rounded-3xl p-12">
          <h2 className="text-4xl font-bold mb-4" style={{ fontFamily: 'Syne' }}>Ready to get started?</h2>
          <p className="text-slate-400 mb-8">Join thousands of educators transforming how they evaluate exams.</p>
          <Link to="/register" className="inline-block bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-500 hover:to-violet-500 px-10 py-4 rounded-xl font-semibold text-lg transition shadow-lg">
            Create Free Account →
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 py-8 px-6 text-center text-slate-500 text-sm">
        <p>© 2024 ExamEvalAI. Built with Gemini AI + React + Node.js</p>
      </footer>
    </div>
  );
};

export default LandingPage;
