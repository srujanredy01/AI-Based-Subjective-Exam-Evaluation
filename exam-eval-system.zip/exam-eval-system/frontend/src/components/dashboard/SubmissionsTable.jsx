import React from 'react';

const statusStyle = {
  submitted: 'bg-blue-500/20 text-blue-400',
  evaluating: 'bg-yellow-500/20 text-yellow-400',
  evaluated: 'bg-green-500/20 text-green-400',
  failed: 'bg-red-500/20 text-red-400',
};

const SubmissionsTable = ({ submissions, onReview }) => {
  if (!submissions.length) {
    return (
      <div className="text-center py-20 text-slate-400">
        <div className="text-5xl mb-4">📤</div>
        <p className="text-lg font-medium mb-2">No submissions yet</p>
        <p className="text-sm">Students haven't submitted any exams</p>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="font-semibold">All Submissions</h3>
          <span className="text-sm text-slate-400">{submissions.length} total</span>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 text-sm">
              <th className="text-left px-6 py-3 font-medium">Student</th>
              <th className="text-left px-6 py-3 font-medium">Exam</th>
              <th className="text-left px-6 py-3 font-medium">Subject</th>
              <th className="text-left px-6 py-3 font-medium">Submitted</th>
              <th className="text-left px-6 py-3 font-medium">Status</th>
              <th className="text-left px-6 py-3 font-medium">Action</th>
            </tr>
          </thead>
          <tbody>
            {submissions.map(sub => (
              <tr key={sub._id} className="border-b border-slate-800/50 hover:bg-slate-800/30 transition">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-violet-600 rounded-full flex items-center justify-center text-xs font-bold">
                      {sub.student?.name?.[0]?.toUpperCase()}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{sub.student?.name}</p>
                      <p className="text-xs text-slate-500">{sub.student?.email}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm">{sub.exam?.title}</td>
                <td className="px-6 py-4 text-sm text-slate-400">{sub.exam?.subject}</td>
                <td className="px-6 py-4 text-sm text-slate-400">
                  {new Date(sub.submittedAt).toLocaleDateString()}
                </td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium capitalize ${statusStyle[sub.status] || ''}`}>
                    {sub.status}
                  </span>
                </td>
                <td className="px-6 py-4">
                  {sub.status === 'evaluated' ? (
                    <button
                      onClick={() => onReview(sub)}
                      className="text-sm text-blue-400 hover:text-blue-300 font-medium"
                    >
                      Review →
                    </button>
                  ) : (
                    <span className="text-xs text-slate-600">
                      {sub.status === 'evaluating' ? '⏳ Processing...' : '—'}
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SubmissionsTable;
