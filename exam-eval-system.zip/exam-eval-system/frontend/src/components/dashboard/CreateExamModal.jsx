import React, { useState } from 'react';
import API from '../../utils/api';
import { toast } from 'react-toastify';

const emptyQuestion = () => ({
  questionText: '', modelAnswer: '', maxMarks: 10,
  rubric: { excellent: '', good: '', average: '', poor: '' },
});

const CreateExamModal = ({ onClose, onCreated }) => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    title: '', subject: '', description: '', duration: 60,
    startTime: '', endTime: '', isPublic: true,
  });
  const [questions, setQuestions] = useState([emptyQuestion()]);

  const updateQuestion = (i, field, val) => {
    setQuestions(prev => prev.map((q, idx) => idx === i ? { ...q, [field]: val } : q));
  };
  const updateRubric = (i, key, val) => {
    setQuestions(prev => prev.map((q, idx) => idx === i ? { ...q, rubric: { ...q.rubric, [key]: val } } : q));
  };

  const handleSubmit = async () => {
    if (!form.title || !form.subject) return toast.error('Title and subject required');
    if (questions.some(q => !q.questionText || !q.modelAnswer)) return toast.error('All questions need text and model answer');
    setLoading(true);
    try {
      const { data } = await API.post('/exams', { ...form, questions });
      onCreated(data.exam);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create exam');
    } finally {
      setLoading(false);
    }
  };

  const inputCls = "w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition text-sm";

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-slate-900 border-b border-slate-800 px-6 py-4 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold">Create New Exam</h2>
            <div className="flex items-center gap-2 mt-1">
              {[1, 2].map(s => (
                <div key={s} className={`h-1.5 w-12 rounded-full transition ${step >= s ? 'bg-blue-500' : 'bg-slate-700'}`} />
              ))}
              <span className="text-xs text-slate-400 ml-1">Step {step} of 2</span>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-xl">✕</button>
        </div>

        <div className="p-6">
          {step === 1 && (
            <div className="space-y-4 animate-fade-in">
              <h3 className="font-semibold text-slate-300 mb-4">Exam Details</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Title *</label>
                  <input className={inputCls} placeholder="e.g., Midterm Physics Exam" value={form.title}
                    onChange={e => setForm(p => ({ ...p, title: e.target.value }))} />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Subject *</label>
                  <input className={inputCls} placeholder="e.g., Physics" value={form.subject}
                    onChange={e => setForm(p => ({ ...p, subject: e.target.value }))} />
                </div>
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">Description</label>
                <textarea className={inputCls} rows={3} placeholder="Optional description..."
                  value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Duration (min)</label>
                  <input className={inputCls} type="number" min="5" value={form.duration}
                    onChange={e => setForm(p => ({ ...p, duration: Number(e.target.value) }))} />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Start Time</label>
                  <input className={inputCls} type="datetime-local" value={form.startTime}
                    onChange={e => setForm(p => ({ ...p, startTime: e.target.value }))} />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">End Time</label>
                  <input className={inputCls} type="datetime-local" value={form.endTime}
                    onChange={e => setForm(p => ({ ...p, endTime: e.target.value }))} />
                </div>
              </div>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={form.isPublic} onChange={e => setForm(p => ({ ...p, isPublic: e.target.checked }))}
                  className="w-4 h-4 rounded" />
                <span className="text-sm text-slate-300">Make exam public (visible to all students)</span>
              </label>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-slate-300">Questions & Rubrics</h3>
                <button onClick={() => setQuestions(p => [...p, emptyQuestion()])}
                  className="text-sm bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded-lg transition flex items-center gap-1">
                  + Add Question
                </button>
              </div>

              {questions.map((q, i) => (
                <div key={i} className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-blue-400">Question {i + 1}</span>
                    {questions.length > 1 && (
                      <button onClick={() => setQuestions(p => p.filter((_, idx) => idx !== i))}
                        className="text-red-400 hover:text-red-300 text-xs">Remove</button>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Question *</label>
                    <textarea className={inputCls} rows={2} placeholder="Enter your question..."
                      value={q.questionText} onChange={e => updateQuestion(i, 'questionText', e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Model Answer *</label>
                    <textarea className={inputCls} rows={3} placeholder="Reference answer..."
                      value={q.modelAnswer} onChange={e => updateQuestion(i, 'modelAnswer', e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Max Marks</label>
                    <input className={`${inputCls} w-24`} type="number" min="1" value={q.maxMarks}
                      onChange={e => updateQuestion(i, 'maxMarks', Number(e.target.value))} />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-2">Rubric (optional)</label>
                    <div className="grid grid-cols-2 gap-2">
                      {['excellent', 'good', 'average', 'poor'].map(key => (
                        <div key={key}>
                          <label className="block text-xs text-slate-500 mb-0.5 capitalize">{key}</label>
                          <input className={inputCls} placeholder={`${key} answer criteria...`}
                            value={q.rubric[key]} onChange={e => updateRubric(i, key, e.target.value)} />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-slate-900 border-t border-slate-800 px-6 py-4 flex items-center justify-between">
          <div className="text-sm text-slate-400">
            {step === 2 && `${questions.length} question(s) · ${questions.reduce((s, q) => s + q.maxMarks, 0)} total marks`}
          </div>
          <div className="flex gap-3">
            {step > 1 && (
              <button onClick={() => setStep(1)} className="px-5 py-2 border border-slate-700 hover:border-slate-600 rounded-xl text-sm transition">
                Back
              </button>
            )}
            {step < 2 ? (
              <button onClick={() => { if (!form.title || !form.subject) { toast.error('Fill required fields'); return; } setStep(2); }}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-500 rounded-xl text-sm font-medium transition">
                Next: Questions →
              </button>
            ) : (
              <button onClick={handleSubmit} disabled={loading}
                className="px-5 py-2 bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-500 hover:to-violet-500 rounded-xl text-sm font-medium transition disabled:opacity-50">
                {loading ? 'Creating...' : '✓ Create Exam'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateExamModal;
