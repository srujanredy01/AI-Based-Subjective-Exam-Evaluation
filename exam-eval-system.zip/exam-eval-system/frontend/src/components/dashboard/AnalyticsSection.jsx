import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const GRADE_COLORS = { 'A+': '#22c55e', A: '#4ade80', 'B+': '#60a5fa', B: '#818cf8', C: '#facc15', D: '#f97316', F: '#f87171' };

const AnalyticsSection = ({ analytics }) => {
  const gradeData = Object.entries(analytics.gradeDistribution).map(([grade, count]) => ({
    grade, count, color: GRADE_COLORS[grade] || '#94a3b8',
  }));

  const stats = [
    { label: 'Total Exams', value: analytics.totalExams, icon: '📋', color: 'text-blue-400' },
    { label: 'Submissions', value: analytics.totalSubmissions, icon: '📤', color: 'text-violet-400' },
    { label: 'Evaluations', value: analytics.totalEvaluations, icon: '✅', color: 'text-green-400' },
    { label: 'Avg Score', value: `${analytics.avgScore}%`, icon: '🎯', color: 'text-yellow-400' },
  ];

  return (
    <div className="animate-fade-in space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map(({ label, value, icon, color }) => (
          <div key={label} className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <p className="text-slate-400 text-sm">{label}</p>
              <span className="text-2xl">{icon}</span>
            </div>
            <p className={`text-3xl font-bold ${color}`}>{value}</p>
          </div>
        ))}
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <h3 className="font-semibold mb-6">Grade Distribution</h3>
        {analytics.totalEvaluations === 0 ? (
          <div className="text-center py-10 text-slate-500">No evaluations yet</div>
        ) : (
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={gradeData}>
              <XAxis dataKey="grade" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 13 }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} allowDecimals={false} />
              <Tooltip
                contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: '12px', color: '#f1f5f9' }}
                formatter={(v) => [v, 'Students']}
              />
              <Bar dataKey="count" radius={[8, 8, 0, 0]}>
                {gradeData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
};

export default AnalyticsSection;
