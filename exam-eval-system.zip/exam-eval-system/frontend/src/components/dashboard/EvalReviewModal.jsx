import React, { useState, useEffect } from 'react';
import API from '../../utils/api';

const EvalReviewModal = ({ submission, onClose }) => {
  const [evaluation, setEvaluation] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const fetch = async () => {
      try {
        const { data } = await API.get(`/evaluations/submission/${submission._id}`);
        setEvaluation(data.evaluation);
        setNotes(data.evaluation.teacherNotes || '');
      } catch {}
      setLoading(false);
    };
    fetch();
  }, [submission._id]);

  const saveNotes = async () => {
    setSaving(true);
    try {
      await API.put(`/evaluations/${evaluation._id}/review`, { teacherNotes: notes });
    } catch {}
    setSaving(false);
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-slate-900 border-b border-slate-800 px-6 py-4 flex items-center justify-between">
          <div>
            <h2 className="font-bold text-lg">AI Evaluation Report</h2>
            <p className="text-sm text-slate-400">{submission.student?.name} — {submission.exam?.title}</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-xl">✕</button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-48">
            <svg className="animate-spin w-8 h-8 text-blue-500" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
            </svg>
          </div>
        ) : !evaluation ? (
          <div className="text-center py-12 text-slate-400">Evaluation not found.</div>
        ) : (
          <div className="p-6 space-y-6">
            {/* Score summary */}
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-gradient-to-br from-blue-500/20 to-violet-500/20 border border-blue-500/30 rounded-2xl p-4 text-center">
                <p className="text-3xl font-bold text-blue-400">{evaluation.totalMarksAwarded}/{evaluation.totalMaxMarks}</p>
                <p className="text-xs text-slate-400 mt-1">Score</p>
              </div>
              <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-4 text-center">
                <p className="text-3xl font-bold text-green-400">{evaluation.percentage.toFixed(1)}%</p>
                <p className="text-xs text-slate-400 mt-1">Percentage</p>
              </div>
              <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-4 text-center">
                <p className="text-3xl font-bold text-yellow-400">{evaluation.grade}</p>
                <p className="text-xs text-slate-400 mt-1">Grade</p>
              </div>
            </div>

            {/* Overall feedback */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
              <h4 className="font-semibold text-sm mb-2 text-slate-300">🤖 AI Overall Feedback</h4>
              <p className="text-slate-400 text-sm leading-relaxed">{evaluation.overallFeedback}</p>
            </div>

            {/* Strengths & improvements */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-green-500/5 border border-green-500/20 rounded-xl p-4">
                <h4 className="font-semibold text-green-400 text-sm mb-3">✓ Strengths</h4>
                <ul className="space-y-1.5">
                  {evaluation.overallStrengths.map((s, i) => (
                    <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                      <span className="text-green-500 mt-0.5">•</span>{s}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-yellow-500/5 border border-yellow-500/20 rounded-xl p-4">
                <h4 className="font-semibold text-yellow-400 text-sm mb-3">→ Areas to Improve</h4>
                <ul className="space-y-1.5">
                  {evaluation.overallAreasOfImprovement.map((a, i) => (
                    <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                      <span className="text-yellow-500 mt-0.5">•</span>{a}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Per-question evaluations */}
            <div>
              <h4 className="font-semibold mb-3">Question-by-Question Breakdown</h4>
              <div className="space-y-3">
                {evaluation.questionEvaluations.map((qe, i) => (
                  <div key={i} className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-blue-400">Q{i + 1}</span>
                      <span className="text-sm font-bold">{qe.marksAwarded}/{qe.maxMarks}</span>
                    </div>
                    <p className="text-sm text-slate-300 mb-2">{qe.questionText}</p>
                    <p className="text-xs text-slate-400 italic">{qe.feedback}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Teacher notes */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Your Notes (optional)</label>
              <textarea
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition text-sm resize-none"
                rows={3} placeholder="Add private notes about this evaluation..."
                value={notes} onChange={e => setNotes(e.target.value)}
              />
              <button onClick={saveNotes} disabled={saving}
                className="mt-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-xl text-sm font-medium transition disabled:opacity-50">
                {saving ? 'Saving...' : 'Save Notes'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EvalReviewModal;
