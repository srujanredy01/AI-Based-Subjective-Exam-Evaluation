import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import { AuthProvider, useAuth } from './context/AuthContext';
import ProtectedRoute from './components/shared/ProtectedRoute';

import LandingPage from './pages/LandingPage';
import AuthPage from './pages/AuthPage';
import TeacherDashboard from './pages/TeacherDashboard';
import StudentDashboard from './pages/StudentDashboard';
import ExamPage from './pages/ExamPage';
import SubmissionStatusPage from './pages/SubmissionStatusPage';
import EvaluationReportPage from './pages/EvaluationReportPage';

const RoleRedirect = () => {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/" replace />;
  return <Navigate to={user.role === 'teacher' ? '/teacher' : '/student'} replace />;
};

const App = () => (
  <AuthProvider>
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<AuthPage mode="login" />} />
        <Route path="/register" element={<AuthPage mode="register" />} />
        <Route path="/dashboard" element={<RoleRedirect />} />

        <Route path="/teacher" element={
          <ProtectedRoute allowedRole="teacher"><TeacherDashboard /></ProtectedRoute>
        } />

        <Route path="/student" element={
          <ProtectedRoute allowedRole="student"><StudentDashboard /></ProtectedRoute>
        } />

        <Route path="/exam/:examId" element={
          <ProtectedRoute allowedRole="student"><ExamPage /></ProtectedRoute>
        } />

        <Route path="/submission/:submissionId" element={
          <ProtectedRoute allowedRole="student"><SubmissionStatusPage /></ProtectedRoute>
        } />

        <Route path="/evaluation/:evalId" element={
          <ProtectedRoute><EvaluationReportPage /></ProtectedRoute>
        } />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
    <ToastContainer
      position="top-right"
      autoClose={3000}
      hideProgressBar={false}
      theme="dark"
      toastStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: '12px' }}
    />
  </AuthProvider>
);

export default App;
