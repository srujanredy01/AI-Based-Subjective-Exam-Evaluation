# ExamEvalAI — Full-Stack AI Exam Evaluation System

> Subjective exam evaluation powered by **Gemini AI**, built with React + Node.js + MongoDB.

---

## 📁 Complete Folder Structure

```
exam-eval-system/
├── backend/
│   ├── config/
│   │   └── db.js                  # MongoDB connection
│   ├── controllers/
│   │   ├── authController.js      # Register, login, getMe
│   │   ├── examController.js      # CRUD + analytics
│   │   ├── submissionController.js
│   │   └── evaluationController.js # Gemini AI integration
│   ├── middleware/
│   │   └── auth.js                # JWT protect + role authorize
│   ├── models/
│   │   ├── User.js                # name, email, password, role
│   │   ├── Exam.js                # title, subject, questions[], rubric
│   │   ├── Submission.js          # exam, student, answers[]
│   │   └── Evaluation.js          # AI scores, feedback, grade
│   ├── routes/
│   │   ├── auth.js
│   │   ├── exams.js
│   │   ├── submissions.js
│   │   └── evaluations.js
│   ├── .env.example
│   ├── package.json
│   └── server.js                  # Express app entry point
│
└── frontend/
    ├── public/
    │   └── index.html
    ├── src/
    │   ├── components/
    │   │   ├── dashboard/
    │   │   │   ├── CreateExamModal.jsx    # 2-step exam creation
    │   │   │   ├── SubmissionsTable.jsx
    │   │   │   ├── AnalyticsSection.jsx   # Recharts grade chart
    │   │   │   └── EvalReviewModal.jsx    # Teacher review modal
    │   │   └── shared/
    │   │       └── ProtectedRoute.jsx
    │   ├── context/
    │   │   └── AuthContext.js     # JWT auth state
    │   ├── pages/
    │   │   ├── LandingPage.jsx    # Hero, stats, features
    │   │   ├── AuthPage.jsx       # Login / Register with role
    │   │   ├── TeacherDashboard.jsx
    │   │   ├── StudentDashboard.jsx
    │   │   ├── ExamPage.jsx       # Typed + file upload
    │   │   ├── SubmissionStatusPage.jsx  # AI processing screen
    │   │   └── EvaluationReportPage.jsx  # Full report
    │   ├── utils/
    │   │   └── api.js             # Axios with JWT interceptor
    │   ├── App.js
    │   ├── index.js
    │   └── index.css
    ├── package.json
    └── tailwind.config.js
```

---

## ⚡ Step-by-Step Setup

### Step 1: Prerequisites
```bash
# Required versions
node --version   # v18+
npm --version    # v9+
```

### Step 2: Clone / Create Project
```bash
mkdir exam-eval-system && cd exam-eval-system
# Copy all files from this guide into their folders
```

### Step 3: MongoDB Atlas Setup
1. Go to https://cloud.mongodb.com
2. Create a free cluster (M0)
3. Create database user (username + password)
4. Whitelist IP: `0.0.0.0/0` (for development)
5. Click "Connect" → "Drivers" → copy the connection string
6. Replace `<username>` and `<password>` in the string

### Step 4: Gemini API Key
1. Go to https://aistudio.google.com/app/apikey
2. Create an API key (free tier available)
3. Copy the key

### Step 5: Backend Setup
```bash
cd backend
cp .env.example .env
# Edit .env with your values:
# MONGO_URI=mongodb+srv://...
# JWT_SECRET=any-long-random-string-here
# GEMINI_API_KEY=your-gemini-key

npm install
npm run dev     # Starts on http://localhost:5000
```

### Step 6: Frontend Setup
```bash
cd ../frontend
npm install
npm start       # Starts on http://localhost:3000
```

---

## 🗺️ API Endpoints

### Auth
| Method | Route | Access | Description |
|--------|-------|--------|-------------|
| POST | `/api/auth/register` | Public | Create account |
| POST | `/api/auth/login` | Public | Login → JWT |
| GET | `/api/auth/me` | Protected | Get current user |

### Exams
| Method | Route | Access | Description |
|--------|-------|--------|-------------|
| GET | `/api/exams` | Protected | List exams (role-filtered) |
| POST | `/api/exams` | Teacher | Create exam |
| GET | `/api/exams/:id` | Protected | Get exam details |
| PUT | `/api/exams/:id` | Teacher | Update exam |
| DELETE | `/api/exams/:id` | Teacher | Delete exam |
| GET | `/api/exams/analytics` | Teacher | Dashboard stats |

### Submissions
| Method | Route | Access | Description |
|--------|-------|--------|-------------|
| POST | `/api/submissions` | Student | Submit answers → triggers AI |
| GET | `/api/submissions/my` | Student | My submissions |
| GET | `/api/submissions/teacher` | Teacher | All submissions |
| GET | `/api/submissions/:id` | Protected | Single submission |

### Evaluations
| Method | Route | Access | Description |
|--------|-------|--------|-------------|
| GET | `/api/evaluations/my` | Student | My evaluations |
| GET | `/api/evaluations/submission/:id` | Protected | Eval by submission |
| PUT | `/api/evaluations/:id/review` | Teacher | Add teacher notes |

---

## 🧠 AI Evaluation Workflow

```
Student submits answers
        ↓
Backend creates Submission (status: evaluating)
        ↓
evaluateWithGemini() called asynchronously
        ↓
For each question:
  - Build prompt: Question + Model Answer + Student Answer + Rubric
  - Call Gemini API (gemini-1.5-flash)
  - Parse JSON response: { marksAwarded, strengths, areasOfImprovement, feedback }
        ↓
Generate overall feedback via second Gemini call
        ↓
Create Evaluation document with all data
        ↓
Update Submission status → 'evaluated'
        ↓
Student polls /submissions/:id → sees 'evaluated'
        ↓
Frontend redirects to EvaluationReportPage
```

### Sample Gemini Prompt Structure:
```
You are an expert academic examiner. Evaluate the student's answer.

QUESTION: [question text]
MODEL ANSWER: [reference answer]
RUBRIC: Excellent (9-10): ..., Good (7-8): ..., etc.
STUDENT ANSWER: [student's response]
MAX MARKS: 10

Respond ONLY in JSON:
{
  "marksAwarded": 8,
  "strengths": ["..."],
  "areasOfImprovement": ["..."],
  "feedback": "...",
  "reasoning": "..."
}
```

---

## 🗄️ MongoDB Collections Schema

### Users
```js
{ name, email, password (hashed), role: 'student'|'teacher', createdAt }
```

### Exams
```js
{
  title, subject, description, teacher: ObjectId,
  questions: [{ questionText, modelAnswer, maxMarks, rubric: {excellent,good,average,poor} }],
  totalMarks, duration, startTime, endTime, status, isPublic
}
```

### Submissions
```js
{
  exam: ObjectId, student: ObjectId,
  answers: [{ questionId, answerText, answerType }],
  status: 'submitted'|'evaluating'|'evaluated'|'failed',
  submittedAt, evaluatedAt
}
```

### Evaluations
```js
{
  submission: ObjectId, exam: ObjectId, student: ObjectId, teacher: ObjectId,
  questionEvaluations: [{ questionId, studentAnswer, marksAwarded, maxMarks, strengths[], areasOfImprovement[], feedback }],
  totalMarksAwarded, totalMaxMarks, percentage, grade,
  overallStrengths[], overallAreasOfImprovement[], overallFeedback,
  aiModel, evaluatedAt, isReviewed, teacherNotes
}
```

---

## 🚀 Deployment

### Deploy Backend to Railway
```bash
# Install Railway CLI
npm install -g @railway/cli
railway login
railway init
railway up

# Set environment variables in Railway dashboard:
# MONGO_URI, JWT_SECRET, GEMINI_API_KEY, NODE_ENV=production
```

### Deploy Frontend to Vercel
```bash
# In frontend/package.json, update proxy to backend URL:
# "proxy": "https://your-railway-backend.up.railway.app"

npm install -g vercel
cd frontend
vercel --prod
```

### Alternative: Deploy to Render + Netlify
```bash
# Backend on Render:
# Build: npm install
# Start: node server.js
# Set env vars in Render dashboard

# Frontend on Netlify:
# Build: npm run build
# Publish: build/
# Set REACT_APP_API_URL env var
```

### Environment Variables Summary
```env
# Backend .env
PORT=5000
MONGO_URI=mongodb+srv://user:pass@cluster.mongodb.net/exameval
JWT_SECRET=super-secret-key-min-32-chars
GEMINI_API_KEY=AIza...
NODE_ENV=production
CLIENT_URL=https://your-frontend.vercel.app
```

---

## 🔧 Common Issues & Fixes

**MongoDB connection fails:**
- Check if IP is whitelisted in Atlas (use 0.0.0.0/0 for dev)
- Verify username/password are URL-encoded if they contain special chars

**Gemini API returns errors:**
- Check your API key at aistudio.google.com
- Free tier has rate limits — the code adds 500ms delays between calls
- Model `gemini-1.5-flash` is free and fast

**CORS errors:**
- Ensure `CLIENT_URL` in backend .env matches your frontend URL exactly
- No trailing slash

**JWT errors:**
- Make sure `JWT_SECRET` is the same value on every server restart
- Tokens expire after 7 days — users need to log in again

---

## 🎯 Feature Checklist

- [x] Landing page with hero, stats, features
- [x] JWT authentication (login/register)
- [x] Role-based access (Teacher/Student)
- [x] Teacher dashboard with sidebar
- [x] Create exam with questions + rubrics (2-step modal)
- [x] Exam table with status badges
- [x] Student dashboard with exam grid cards
- [x] Countdown timer for active exams
- [x] Exam taking page — typed OR file upload
- [x] Drag & drop file upload
- [x] Progress bar showing answered questions
- [x] AI evaluation via Gemini API
- [x] Submission status polling page
- [x] Full evaluation report with circular score gauge
- [x] Per-question breakdown with expand/collapse
- [x] Strengths & Areas of Improvement
- [x] Teacher can review evaluations and add notes
- [x] Analytics dashboard with grade distribution chart
- [x] Responsive UI throughout
- [x] Error handling & loading states
- [x] Toast notifications

---

Built with ❤️ using React, Node.js, MongoDB, and Google Gemini AI
